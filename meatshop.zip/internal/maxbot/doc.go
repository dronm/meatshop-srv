// Package maxbot
package maxbot
